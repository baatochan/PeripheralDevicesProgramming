﻿namespace Joystick
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if ( disposing && (components != null) )
            {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_znajdz = new System.Windows.Forms.Button();
            this.btn_kieruj = new System.Windows.Forms.Button();
            this.nazwa = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.os_x = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.os_y = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.os_z = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_znajdz
            // 
            this.btn_znajdz.Location = new System.Drawing.Point( 246, 113 );
            this.btn_znajdz.Name = "btn_znajdz";
            this.btn_znajdz.Size = new System.Drawing.Size( 114, 24 );
            this.btn_znajdz.TabIndex = 0;
            this.btn_znajdz.Text = "znajdz urzadzenie";
            this.btn_znajdz.UseVisualStyleBackColor = true;
            this.btn_znajdz.Click += new System.EventHandler( this.btn_znajdz_Click );
            // 
            // btn_kieruj
            // 
            this.btn_kieruj.Location = new System.Drawing.Point( 246, 165 );
            this.btn_kieruj.Name = "btn_kieruj";
            this.btn_kieruj.Size = new System.Drawing.Size( 113, 24 );
            this.btn_kieruj.TabIndex = 1;
            this.btn_kieruj.Text = "kieruj joystickiem";
            this.btn_kieruj.UseVisualStyleBackColor = true;
            this.btn_kieruj.Click += new System.EventHandler( this.btn_kieruj_Click );
            // 
            // nazwa
            // 
            this.nazwa.AutoSize = true;
            this.nazwa.Location = new System.Drawing.Point( 28, 34 );
            this.nazwa.Name = "nazwa";
            this.nazwa.Size = new System.Drawing.Size( 92, 13 );
            this.nazwa.TabIndex = 2;
            this.nazwa.Text = "nazwa urzadzenia";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point( 31, 64 );
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size( 170, 20 );
            this.textBox1.TabIndex = 3;
            // 
            // os_x
            // 
            this.os_x.AutoSize = true;
            this.os_x.Location = new System.Drawing.Point( 28, 113 );
            this.os_x.Name = "os_x";
            this.os_x.Size = new System.Drawing.Size( 28, 13 );
            this.os_x.TabIndex = 4;
            this.os_x.Text = "os X";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point( 31, 143 );
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size( 77, 20 );
            this.textBox2.TabIndex = 5;
            // 
            // os_y
            // 
            this.os_y.AutoSize = true;
            this.os_y.Location = new System.Drawing.Point( 135, 113 );
            this.os_y.Name = "os_y";
            this.os_y.Size = new System.Drawing.Size( 28, 13 );
            this.os_y.TabIndex = 6;
            this.os_y.Text = "os Y";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point( 138, 144 );
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size( 77, 20 );
            this.textBox3.TabIndex = 7;
            // 
            // os_z
            // 
            this.os_z.AutoSize = true;
            this.os_z.Location = new System.Drawing.Point( 28, 189 );
            this.os_z.Name = "os_z";
            this.os_z.Size = new System.Drawing.Size( 28, 13 );
            this.os_z.TabIndex = 8;
            this.os_z.Text = "oz Z";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point( 31, 223 );
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size( 76, 20 );
            this.textBox4.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF( 6F, 13F );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size( 386, 306 );
            this.Controls.Add( this.textBox4 );
            this.Controls.Add( this.os_z );
            this.Controls.Add( this.textBox3 );
            this.Controls.Add( this.os_y );
            this.Controls.Add( this.textBox2 );
            this.Controls.Add( this.os_x );
            this.Controls.Add( this.textBox1 );
            this.Controls.Add( this.nazwa );
            this.Controls.Add( this.btn_kieruj );
            this.Controls.Add( this.btn_znajdz );
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler( this.Form1_Load );
            this.ResumeLayout( false );
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_znajdz;
        private System.Windows.Forms.Button btn_kieruj;
        private System.Windows.Forms.Label nazwa;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label os_x;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label os_y;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label os_z;
        private System.Windows.Forms.TextBox textBox4;
    }
}

