﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Management;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;

namespace JoystickApp
{
    public partial class Form1 : Form
    {
        private Joystick joystick;

        Graphics g; // udostępnienie metod umożliwiających rysowanie
        Pen pen = new Pen(Color.Black, 1); // obiekt rysujący
        Point sp = new Point(0, 0); // punkt startowy
        Point ep = new Point(0, 0); // punkt końcowy
        int k = 0; // stan lewego przycisku myszy

        public Form1()
        {
            InitializeComponent();
            joystick = new Joystick(this.Handle);
            connectToJoystick(joystick);
            this.Text = joystick.joyName;
        }

        private void connectToJoystick(Joystick joystick)
        {
            while (true)
            {
                string sticks = joystick.FindJoysticks();
                if (sticks != null)
                {
                    if (joystick.AcquireJoystick(sticks))
                    {
                        joystickTimer.Enabled = true;
                        break;
                    }
                }
            }
        }

        // generowanie zdarzenia cyklicznego
        private void joystickTimer_Tick_1(object sender, EventArgs e)
        {
            try
            {
                joystick.UpdateStatus();
            }
            catch
            {
                joystickTimer.Enabled = false;
                connectToJoystick(joystick);
            }
        }

        // okienka z odpowiadającą barwą do wyboru koloru rysowania
        private void redBox_Click(object sender, EventArgs e)
        {
            pen.Color = redBox.BackColor;
            mainBox.BackColor = redBox.BackColor;
        }

        private void blueBox_Click(object sender, EventArgs e)
        {
            pen.Color = blueBox.BackColor;
            mainBox.BackColor = blueBox.BackColor;
        }

        private void greenBox_Click(object sender, EventArgs e)
        {
            pen.Color = greenBox.BackColor;
            mainBox.BackColor = greenBox.BackColor;
        }

        private void blackBox_Click(object sender, EventArgs e)
        {
            pen.Color = blackBox.BackColor;
            mainBox.BackColor = blackBox.BackColor;
        }

        // aktualizacja stanu lewego przycisku myszy
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            sp = e.Location;
            if (e.Button == MouseButtons.Left)
                k = 1;
        }

        // aktualizacja stanu lewego przycisku myszy
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            k = 0;
        }

        // funkcją rysująca linię w przypadku ruchu kursora z wciśniętym lewym przyciskiem myszy
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (k == 1)
            {
                ep = e.Location;
                g = this.CreateGraphics();
                g.DrawLine(pen, sp, ep); // wywołanie funkcji rysującej linię
            }
            sp = ep;
        }
    }
}
